/*
	Author:      Claire Lopez
    Date:        15 nov. 2020
 */

package ch.epfl.cs107.play.game.actor.tutos.area.tuto1;

import ch.epfl.cs107.play.game.actor.tutos.area.SimpleArea;
import ch.epfl.cs107.play.game.areagame.actor.Background;

public class Ferme extends SimpleArea {
	
	@Override
	public String getTitle() {
		return "zelda/Ferme";
	}

	@Override
	protected void createArea() {
        // Base
        registerActor(new Background(this));
	}
	
}

