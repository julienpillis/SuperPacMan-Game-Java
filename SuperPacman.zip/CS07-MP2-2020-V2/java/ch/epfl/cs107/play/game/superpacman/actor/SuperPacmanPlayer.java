package ch.epfl.cs107.play.game.superpacman.actor;

import java.util.Collections;
import java.util.List;
import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Animation;
import ch.epfl.cs107.play.game.areagame.actor.Interactable;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.rpg.actor.Door;
import ch.epfl.cs107.play.game.rpg.actor.Player;
import ch.epfl.cs107.play.game.rpg.actor.RPGSprite;
import ch.epfl.cs107.play.game.superpacman.area.SuperPacmanArea;
import ch.epfl.cs107.play.game.superpacman.handler.SuperPacmanInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.window.Canvas;
import ch.epfl.cs107.play.window.Keyboard;

public class SuperPacmanPlayer extends Player {
	
	//private Sprite sprite;
	private Orientation desiredOrientation;
	private SuperPacmanPlayerHandler SuperPacmanPlayerHandler = new SuperPacmanPlayerHandler();
	
	// Animation duration in frame number
    private final static int ANIMATION_DURATION = 25;
    private Animation animations[];
    private final int maxLife = 5;
    private int life = 3;
    private int score = 0;
    private SuperPacmanPlayerGUI tab;
    private boolean invulnerability;
    private float currentBonusTimer;
    private float currentCherryTimer=0;
    private boolean stateTransition;
    private int cherrySpeed=2;
    private float currentExplosionTimer;
    private Clyde clyde;
    private SuperPacmanPlayer player;
    private boolean win;
    /*
     * Default SuperPacmanPlayer constructor
	 * @param area (Area) : Owner area. Not null 
	 * @param position (DiscreteCoordinates): The SuperPacmanPlayer position. Not null
	*/
	public SuperPacmanPlayer(Area owner, DiscreteCoordinates coordinates) {
		super(owner, Orientation.UP, coordinates);
		Sprite[][] sprites = RPGSprite.extractSprites("superpacman/pacman", 4, 1, 1, this, 64, 64, new Orientation[] {Orientation.DOWN, Orientation.LEFT, Orientation.UP, Orientation.RIGHT});
		animations = Animation.createAnimations(ANIMATION_DURATION / 4, sprites);
		tab = new SuperPacmanPlayerGUI(score,maxLife,life);
		invulnerability = false;
		player=this;
	}
	
	
	private class SuperPacmanPlayerHandler implements SuperPacmanInteractionVisitor {

		public void interactWith(Door door) {
	        setIsPassingADoor(door);
	    }
		public void interactWith(Shadow shadow) {
			life =0;
	    }
		public void interactWith(Heart heart) {
	        if(life<maxLife) {
	        	++life;
	        }
	    }
		public void interactWith(Bomb bomb) {
			setCurrentExplosionTimer(bomb.getExplosionTimer());
			currentExplosionTimer = bomb.getExplosionTimer();
			bomb.explosion();
			 score -= bomb.score();
		}
		public void interactWith(Teleportation teleportation) {
			setIsPassingADoor(teleportation.getTeleportationDoor());
		}
		public void interactWith(Cherry cherry) {
	        score += cherry.score();
	        ((SuperPacmanArea)getOwnerArea()).setSpeed(cherrySpeed);
	        currentCherryTimer=3;
	    }
		
		public void interactWith(Diamond diamond) {
	        score += diamond.score();
	        ((SuperPacmanArea)getOwnerArea()).removeADiamond();
	    }
		public void interactWith(CellOver cellOver) {
	        win=true;
	    }
		
		public void interactWith(Key key) {
			key.collect();
		}
		public void interactWith(Clyde key) {
			life-=1;
		}
		
		public void interactWith(Bonus bonus) {
			setCurrentBonusTimer(bonus.getBonusTimer());
			currentBonusTimer = bonus.getBonusTimer();
			if(((SuperPacmanArea)getOwnerArea()).getTitle()=="superpacman/Level3"&&clyde==null) {  // We don't want 2 Clydes at the same time and only in level3
				clyde = new Clyde(getOwnerArea(),Orientation.UP, new DiscreteCoordinates(14,9),player);
				getOwnerArea().registerActor(clyde);
				
			}
		}
		
		public void interactWith(Ghost ghost) {
			if(invulnerability&&ghost.getIsGhostAfraid()) {     // the second condition is usefull for the ghost Clyde 
				score += ghost.score();
				ghost.isAte();
			}
			else {
				if (life>0) {
					--life;
					((SuperPacmanArea)getOwnerArea()).ateGhosts();
					goToSpawnPosition();
				}
			}
		}
	}
	/*
	 * Method to set the player to his spawn position when he/she dies
	 */
	public void goToSpawnPosition() {
		float x  = ((SuperPacmanArea)getOwnerArea()).getPlayerSpawnPosition().x;
		float y = ((SuperPacmanArea)getOwnerArea()).getPlayerSpawnPosition().y;
		Vector newPosition = new Vector(x,y);
		getOwnerArea().leaveAreaCells(this , getEnteredCells());
		setCurrentPosition(newPosition);
		getOwnerArea().enterAreaCells(this , getCurrentCells());
		resetMotion();
	}
	
	 @Override	 
	 public void update(float deltaTime) {
		 
        Keyboard keyboard= getOwnerArea().getKeyboard();
        
        if(keyboard.get(Keyboard.UP).isDown()) {
            desiredOrientation = Orientation.UP;
        }
        
        else if(keyboard.get(Keyboard.DOWN).isDown()){
            desiredOrientation = Orientation.DOWN;
        }
        
        else if(keyboard.get(Keyboard.LEFT).isDown()){
            desiredOrientation = Orientation.LEFT;
        }
        
        else if(keyboard.get(Keyboard.RIGHT).isDown()){
            desiredOrientation = Orientation.RIGHT;
        } 
        
        if(!isDisplacementOccurs() && desiredOrientation!=null) {
            if(getOwnerArea().canEnterAreaCells(this,Collections.singletonList(getCurrentMainCellCoordinates().jump(desiredOrientation.toVector())))) {
                orientate(desiredOrientation);
            }
            move(((SuperPacmanArea)getOwnerArea()).getSpeed());             
        }
        
        if (!isDisplacementOccurs()) {
        	move(((SuperPacmanArea)getOwnerArea()).getSpeed());
            animations[getOrientation().ordinal()].reset();
        }

        if(currentBonusTimer>0) {
        	invulnerability = true;
        	currentBonusTimer-=deltaTime;
        }
        
        else {
        	invulnerability = false;
        	setCurrentBonusTimer(0);
        	if(getOwnerArea().exists(clyde)) {
        		getOwnerArea().leaveAreaCells(clyde , getEnteredCells());
        		getOwnerArea().unregisterActor(clyde);
        		clyde=null;
        	}
        }
        if(currentCherryTimer>0) {
        	currentCherryTimer-=deltaTime;
        	((SuperPacmanArea)getOwnerArea()).setSpeed(cherrySpeed);
        }
        else {
        	((SuperPacmanArea)getOwnerArea()).setSpeed(((SuperPacmanArea)getOwnerArea()).getNormalSpeed());
        }
        stateTransition=false;
        animations[getOrientation().ordinal()].update(deltaTime);
        tab = new SuperPacmanPlayerGUI(score,maxLife,life);
        super.update(deltaTime);
	 }
	 
	 
    /**
     * Leave an area by unregister this player
     */
    public void leaveArea(){
        getOwnerArea().unregisterActor(this);
    }
    
    
	@Override
	public void draw(Canvas canvas) {
		animations[getOrientation().ordinal()].draw(canvas);
		tab.draw(canvas);
	}
	
	
	@Override
	public boolean takeCellSpace() {
		return false;
	}
	// We made the choice to set takeCellSpace to false because now, the player is eatable even when he doesn't move

	
	@Override
	public boolean isCellInteractable() {
		return true;
	}

	
	@Override
	public boolean isViewInteractable() {
		return true;
	}
	
	
	@Override
	public List<DiscreteCoordinates> getCurrentCells() {
		return Collections.singletonList(getCurrentMainCellCoordinates());
	}
	
	
	@Override
	public void acceptInteraction(AreaInteractionVisitor v) {
		((SuperPacmanInteractionVisitor)v).interactWith(this);
	}

	
	@Override
	public List<DiscreteCoordinates> getFieldOfViewCells() {
		return null;
	}

	
	@Override
	public boolean wantsCellInteraction() {
		return true;
	}
	
	
	@Override
	public boolean wantsViewInteraction() {
		return false;
	}
	
	
	@Override
	public void interactWith(Interactable other) {
		other.acceptInteraction(SuperPacmanPlayerHandler);
	}
	
	
	/*
	 * Method that sets the Timer of Invulnerability
	 */
	public void setCurrentBonusTimer(float timer) {
		currentBonusTimer = timer;
		stateTransition=true;
		
	}
	
	/*
	 * Getter of the player Current Bonus Timer
	 */
	public float getCurrentBonusTimer() {
		return currentBonusTimer;
	}
	
	/*
	 * Getter of the player state of Transition
	 */
	public boolean getStateTransition() {
		return stateTransition;
	}
	
	
	/*
	 * Method to initiate the if the moment is a transition or not
	 */
	public void setStateTransition(boolean a) {
		stateTransition=a;
	}
	
	
	/*
	 * getter of the players's invulnerability
	 */
	public boolean isInvulnerable() {
		return invulnerability;
	}
	
	/*
	 * getter of the players's position
	 */
	public DiscreteCoordinates getPlayerPos() {
        return this.getCurrentCells().get(0);
    }
	/*
	 * getter of the current score
	 */
	public int getScore() {
		return score;
	}
	
	/*
	 * getter of the current number of lives
	 */
	public int getLife() {
		return life;
	}
	private void setCurrentExplosionTimer(float timer) {
		currentExplosionTimer = timer;
	}
	/*
	* getter that indicates if the player won the game
	*/
	public boolean getWin() {
		return win;
	}
}