package ch.epfl.cs107.play.game.superpacman.actor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.AreaGraph;
import ch.epfl.cs107.play.game.areagame.actor.Animation;
import ch.epfl.cs107.play.game.areagame.actor.Interactable;
import ch.epfl.cs107.play.game.areagame.actor.Interactor;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.rpg.actor.Player;
import ch.epfl.cs107.play.game.rpg.actor.RPGSprite;
import ch.epfl.cs107.play.game.superpacman.area.SuperPacmanArea;
import ch.epfl.cs107.play.game.superpacman.handler.SuperPacmanInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.RandomGenerator;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.window.Canvas;

public class Ghost extends Player implements Interactor {
	
	private SuperPacmanPlayer memory;
	private final static int NORMAL_SPEED = 18;
	private final static int ANIMATION_DURATION = 25;			
    private int GHOST_SCORE = 500;
    private int currentSpeed = NORMAL_SPEED;
    
    private float currentBonusTimer;
    private Orientation desiredOrientation;
    private DiscreteCoordinates refuge;
    private Animation animationsAfraid;
    private boolean isGhostAfraid;
    private AreaGraph graph;
    private DiscreteCoordinates targetPos=null;
    private GhostHandler GhostHandler = new GhostHandler();
    private boolean stateTransition;
    private Ghost ghost;
    
    
    /*
     * Default Ghost constructor
	 * @param area (Area) : Owner area. Not null 
	 * @param orientation(Orientation) : Ghost orientation. Not null
	 * @param position (DiscreteCoordinates): The ghost position. Not null
	*/
	public Ghost(Area area, Orientation orientation, DiscreteCoordinates coordinates) {
		super(area, orientation, coordinates);
		desiredOrientation = orientation;
		refuge=coordinates;
		ghost=this;
		Sprite[] ghostAfraid = RPGSprite.extractSprites("superpacman/ghost.afraid", 2, 1, 1, this, 16, 16);
		animationsAfraid = new Animation(ANIMATION_DURATION / 4, ghostAfraid);
		isGhostAfraid = false;
		graph = ((SuperPacmanArea)getOwnerArea()).getGraph();
	
	}
	
	/* 
	 * Method to increase the number of Pacman points if the phantom is eaten
	 */
	public int score() {
		return GHOST_SCORE;
	}
	
	class GhostHandler implements SuperPacmanInteractionVisitor {
		
    	public void interactWith(SuperPacmanPlayer player) {	
    		if(memory==null&&isGhostAfraid==false) {
    			memory = player;
    			stateTransition=true;
    		}
    	}
	}
	
	public void update(float deltaTime) {
		
		if(currentBonusTimer>0) {
        	isGhostAfraid = true;
        	memory=null;
        	currentBonusTimer-=deltaTime;
        	
        }
        else {
        	isGhostAfraid = false;
        	setCurrentBonusTimer(0);
        }	
		
		if(isDisplacementOccurs()) {
			if(isGhostAfraid && currentBonusTimer>0) {
               animationsAfraid.update(deltaTime);
			}
		}
		else {
			getNextOrientation();
			if (desiredOrientation != null ) {
			     orientate(desiredOrientation);
			     move(currentSpeed);
			}
		}
		//stateTransition=false;
		super.update(deltaTime);
	}
	
	/* 
	 * Method when ghost is eaten by pacman, unregister player in memory and ghost spawn to his refuge
	 */
	public void isAte() {
		float x  = refuge.x;
		float y = refuge.y;
		Vector newPosition = new Vector(x,y);
		getOwnerArea().leaveAreaCells(this , getEnteredCells());
		setCurrentPosition(newPosition);
		getOwnerArea().enterAreaCells(this, getCurrentCells());
		resetMotion();
		memory=null;
	}
	
	public void ghostIsAfraid() {
		isGhostAfraid = true;
		currentBonusTimer = ((SuperPacmanArea)getOwnerArea()).getCurrentVulTimer();
		memory=null;
	}
	
	/* 
	 * Method that determines the orientation of the phantom if it detects the pacman in the cells it can see
	 */
	protected void getNextOrientation() {
	}
	
	@Override
	public List<DiscreteCoordinates> getCurrentCells() {
		return Collections.singletonList(getCurrentMainCellCoordinates());
	}

	/** 
     * Method of determining whether Pacman is in his field of vision
     *  Returns a List of Discrete Coordiantes that describes whether or not the cells are traversable
     * */ 
    @Override
    public List<DiscreteCoordinates> getFieldOfViewCells() {
    	
    	List<DiscreteCoordinates> coordinatesFieldOfView = new ArrayList<DiscreteCoordinates>();
    	
        for (int i = -2; i<3; i++) {
            for (int j = -2; j<3; j++) {
                coordinatesFieldOfView.add(new DiscreteCoordinates(getCurrentMainCellCoordinates().x+i,getCurrentMainCellCoordinates().y+j));
            }
        }
        return coordinatesFieldOfView;
    }

	
	@Override
	public boolean wantsCellInteraction() {
		return false;
	}

	
	@Override
	public boolean wantsViewInteraction() {
		return true;
	}

	
	@Override
	public void interactWith(Interactable other) {	
		other.acceptInteraction(GhostHandler);
	}

	
	@Override
	public boolean takeCellSpace() {
		return false;
	}

	
	@Override
	public boolean isCellInteractable() {
		return true;
	}

	
	@Override
	public boolean isViewInteractable() {
		return false;
	}
	
	
	@Override
	public void acceptInteraction(AreaInteractionVisitor v) {
		((SuperPacmanInteractionVisitor)v).interactWith(this);
	}
	
	
	@Override
	public void draw(Canvas canvas) {	
		if (isGhostAfraid) {
			animationsAfraid.draw(canvas);
		}
	}
	
	
	public void setCurrentBonusTimer(float timer) {
		currentBonusTimer=timer;
	}
	
	
	public void setStateTransition(boolean isTransition) {
		stateTransition=isTransition;
	}
	
	
	public boolean getStateTransition() {
		return stateTransition;
	}
	
	
	protected DiscreteCoordinates randomCoordinatesGenerator() {
		int x = RandomGenerator.getInstance().nextInt(getOwnerArea().getWidth());
		int y = RandomGenerator.getInstance().nextInt(getOwnerArea().getHeight());
		DiscreteCoordinates randomCoordinates = new DiscreteCoordinates(x,y);
		return randomCoordinates;
	}
	
	
	protected int getNormalSpeed() {
		return NORMAL_SPEED;
	}
	
	
	protected void setCurrentSpeed(int speed) {
		currentSpeed=speed;
	}
	
	
	protected SuperPacmanPlayer getMemory() {
		return memory;
	}
	
	
	protected AreaGraph getGraph() {
		return graph;
	}
	
	
	protected void setDesiredOrientation(Orientation orientation) {
		desiredOrientation=orientation;
	}
	
	
	protected DiscreteCoordinates getRefuge() {
		return refuge;
	}
	
	
	protected void setTargetPos(DiscreteCoordinates position) {
		targetPos=position;
	}
	
	
	protected DiscreteCoordinates getTargetPos() {
		return targetPos;
	}
	
	
	protected boolean getIsGhostAfraid() {
		return isGhostAfraid;
	}
}
