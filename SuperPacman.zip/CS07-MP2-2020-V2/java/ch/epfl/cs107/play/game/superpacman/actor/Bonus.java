package ch.epfl.cs107.play.game.superpacman.actor;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Animation;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.rpg.actor.RPGSprite;
import ch.epfl.cs107.play.game.superpacman.handler.SuperPacmanInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Canvas;

public class Bonus extends CollectableAreaEntity{

    private Sprite[] bonus;
    private final static int ANIMATION_DURATION = 25;
    private final static float INVULNERABILITY_TIMER = 10;
    private Animation animations;

    /*
     * Default Bonus constructor
     * @param area (Area) : Owner area. Not null 
     * @param orientation(Orientation) : Bonus orientation. Not null
     * @param position (DiscreteCoordinates): The bonus position. Not null
    */
    public Bonus(Area area, Orientation orientation, DiscreteCoordinates position) {
        super(area,orientation,position);
        bonus = RPGSprite.extractSprites("superpacman/coin", 4, 1, 1, this , 16, 16);
        animations = new Animation(ANIMATION_DURATION / 4, bonus);
    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        animations.update(deltaTime);
    }
    @Override
    public void draw(Canvas canvas) {
        animations.draw(canvas);
    }
    
    /**
     * If the method collect is called. The signal of the key becomes TRUE. 
     */
    @Override
    public void acceptInteraction(AreaInteractionVisitor v) {
        ((SuperPacmanInteractionVisitor)v).interactWith(this);
        getOwnerArea().unregisterActor(this);
    }
    /*
     * Getter of the duration of the bonus when eatten by the player
     */
    public float getBonusTimer() {
        return INVULNERABILITY_TIMER;
    }
}