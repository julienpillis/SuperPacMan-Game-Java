package ch.epfl.cs107.play.game.superpacman.actor;

import java.util.Queue;
import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Animation;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Path;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.rpg.actor.RPGSprite;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Canvas;

public class Pinky extends IntelligentGhost {

	private Sprite[][] pinky;
	private final static int ANIMATION_DURATION = 25;
    private Animation animations[];
    private final static int MIN_DISTANCE_WHEN_SCARED=5;
    private final static int MAX_RANDOM_ATTEMPT =200;
    private int attempt;
    
    
    /*
     * Default Pinky constructor
	 * @param area (Area) : Owner area. Not null 
	 * @param orientation(Orientation) : Pinky orientation. Not null
	 * @param position (DiscreteCoordinates): The pinky position. Not null
	*/
	public Pinky(Area area, Orientation orientation, DiscreteCoordinates coordinates) {
		super(area, orientation, coordinates);
		pinky = RPGSprite.extractSprites("superpacman/ghost.pinky", 2, 1, 1, this, 16, 16, new Orientation[] {Orientation.UP, Orientation.RIGHT, Orientation.DOWN, Orientation.LEFT});
		animations = Animation.createAnimations(ANIMATION_DURATION / 4, pinky);
	}

	
	@Override
	public void draw(Canvas canvas) {
		super.draw(canvas);
		if(!getIsGhostAfraid()) {
			animations[getOrientation().ordinal()].draw(canvas);
		}
	}

	@Override
	protected DiscreteCoordinates targetCellRandom(DiscreteCoordinates target, Queue<Orientation> path) {
		
		float distance;
		DiscreteCoordinates position;
		attempt=0;
		
		if (path == null) {
			if (getIsGhostAfraid()) {
			 do {
				 attempt = attempt +1;
				 position = randomCoordinatesGenerator();
				 distance = DiscreteCoordinates.distanceBetween(position, target);
			 } while(distance < MIN_DISTANCE_WHEN_SCARED && attempt > MAX_RANDOM_ATTEMPT) ;
			 return position;
			}
			
			else {
				position = randomCoordinatesGenerator();
			return position;
			}
		}
		else {
			return getTargetPos();
		}
	}
	
	
	@Override
	public void update(float deltaTime) {
		super.update(deltaTime);
		if((!getIsGhostAfraid())&&(isDisplacementOccurs())) {
			animations[getOrientation().ordinal()].update(deltaTime);
		}
	}
}

