package ch.epfl.cs107.play.game.superpacman.actor;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.superpacman.handler.SuperPacmanInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Canvas;

public class Cherry extends CollectableAreaEntity {
	
    private Sprite cherry;
    private final static int CHERRY_POINTS = 200; 
    
    /*
     * Default Cherry constructor
	 * @param area (Area) : Owner area. Not null 
	 * @param orientation(Orientation) : cherry orientation. Not null
	 * @param position (DiscreteCoordinates): The cherry position. Not null
	*/
    public Cherry(Area area, Orientation orientation, DiscreteCoordinates position) {
        super(area,orientation,position);
        cherry = new Sprite("superpacman/cherry", 1, 1,this);
    }
    /*
	 * Getter of the bonus points that the player will have when he/she eat a cherry
	 */
    public int score() {
        return CHERRY_POINTS;
    }
    @Override
    public void draw(Canvas canvas) {
        cherry.draw(canvas);
    }
    
    @Override
    public void acceptInteraction(AreaInteractionVisitor v) {
    	((SuperPacmanInteractionVisitor)v).interactWith(this);
        getOwnerArea().unregisterActor(this);
    }
}
