package ch.epfl.cs107.play.game.superpacman.actor;

import java.util.Collections;
import java.util.List;
import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Animation;
import ch.epfl.cs107.play.game.areagame.actor.Interactable;
import ch.epfl.cs107.play.game.areagame.actor.Interactor;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.rpg.actor.Door;
import ch.epfl.cs107.play.game.rpg.actor.Player;
import ch.epfl.cs107.play.game.rpg.actor.RPGSprite;
import ch.epfl.cs107.play.game.superpacman.handler.SuperPacmanInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.signal.logic.Logic;
import ch.epfl.cs107.play.window.Canvas;

public class Teleportation extends CollectableAreaEntity {
	
    private final static int ANIMATION_DURATION = 25;			
    private Animation animationsTeleportation;
    private Door door;
    private DiscreteCoordinates coordinates;
    private DiscreteCoordinates coordinatesT;
 
	public Teleportation(Area area, Orientation orientation, DiscreteCoordinates coordinates, DiscreteCoordinates coordinatesT) {
		super(area, orientation, coordinates);
		this.coordinates=coordinates;
		this.coordinatesT = coordinatesT;
		Sprite[] teleportation = RPGSprite.extractSprites("zelda/orb", 6, 1, 1, this, 32, 32);
		animationsTeleportation = new Animation(ANIMATION_DURATION / 4, teleportation);
		door =new Door(getOwnerArea().getTitle(), coordinatesT, Logic.TRUE, getOwnerArea(), Orientation.UP, coordinates);
	}

	@Override
	public void update(float deltaTime) {
		super.update(deltaTime);
		animationsTeleportation.update(deltaTime);
	}

	public void draw(Canvas canvas) {
		animationsTeleportation.draw(canvas);
	}

	/**
 	* If the method collect is called. The signal of the key becomes TRUE. 
 	*/
	@Override
	public void acceptInteraction(AreaInteractionVisitor v) {
    	((SuperPacmanInteractionVisitor)v).interactWith(this);
    	//getOwnerArea().unregisterActor(this);
	}
	/*
	 * Getter of the teleportation door
	 */
	public Door getTeleportationDoor() {
		return door;
	}
}
