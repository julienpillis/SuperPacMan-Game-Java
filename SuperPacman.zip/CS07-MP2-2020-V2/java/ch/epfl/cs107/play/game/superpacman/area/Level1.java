package ch.epfl.cs107.play.game.superpacman.area;

import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.rpg.actor.Door;
import ch.epfl.cs107.play.game.superpacman.actor.Bomb;
import ch.epfl.cs107.play.game.superpacman.actor.Gate;
import ch.epfl.cs107.play.game.superpacman.actor.Heart;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.signal.logic.Logic;

public class Level1 extends SuperPacmanArea {
	
	public final static DiscreteCoordinates PLAYER_SPAWN_POSITION = new DiscreteCoordinates(15,6);
	private final static int NORMAL_SPEED = 5;
	private int SPEED = 5;
	
	
	@Override
	public String getTitle() {
		return "superpacman/Level1";
	}
	
	@Override
	protected void createArea() {
		registerActor(new Heart(this, Orientation.UP, new DiscreteCoordinates(19,26)));
		registerActor(new Bomb(this, Orientation.UP, new DiscreteCoordinates(16,13)));
		registerActor(new Bomb(this, Orientation.UP, new DiscreteCoordinates(13,13)));
		registerActor(new Door("superpacman/Level2",new DiscreteCoordinates(15,29),Logic.TRUE,this,Orientation.UP,new DiscreteCoordinates(14,0),new DiscreteCoordinates(15,0)));
		registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(14,3),this));
		registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(15,3),this));
	}
	
	
	@Override
	public DiscreteCoordinates getPlayerSpawnPosition() {
		return PLAYER_SPAWN_POSITION;
	}
	
	@Override
	public void setSpeed(int speed) {
		SPEED=speed;
	}
	
	@Override
	public int getNormalSpeed() {
		return NORMAL_SPEED;
	}
	@Override
	public int getSpeed() {
		return SPEED;
	}
}
