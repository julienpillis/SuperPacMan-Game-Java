package ch.epfl.cs107.play.game.superpacman.actor;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.superpacman.handler.SuperPacmanInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.signal.logic.Logic;
import ch.epfl.cs107.play.window.Canvas;

public class Key extends CollectableAreaEntity implements Logic {
	
	private boolean signal;
	private Sprite key;

	/**
     * Default Key constructor
     * @param area (Area): Owner Area, not null
     * @param orientation (Orientation): Initial key orientation, not null
     * @param coordinates (Coordinates): Initial position, not null
     */
	    public Key(Area area, Orientation orientation, DiscreteCoordinates position) {
	        super(area,orientation,position);
	        key = new Sprite("superpacman/key", 1, 1,this);
	        signal = false;
	    }
	    @Override
	    public void draw(Canvas canvas) {
	    	super.draw(canvas);
	        key.draw(canvas);
	    }
	    
	    @Override
	    public void acceptInteraction(AreaInteractionVisitor v) {
	    	((SuperPacmanInteractionVisitor)v).interactWith(this);
	    	 getOwnerArea().unregisterActor(this);
	    }
	    
	    /**
	     * If the method collect is called. The signal of the key becomes TRUE. 
	     */
	    public void collect() {
	    	signal = true;
	    }
	    
		@Override
		public boolean isOn() {
			return !signal;
		}

		@Override
		public boolean isOff() {
			return signal;
		}

		@Override
		public float getIntensity() {
			if (signal == false) {
				return 1;
			}
			else {
				return 0;
			}
		}	
}
