package ch.epfl.cs107.play.game.superpacman.actor;

import java.util.Queue;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Animation;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.rpg.actor.RPGSprite;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.RandomGenerator;
import ch.epfl.cs107.play.window.Canvas;

public class Clyde extends IntelligentGhost {
	
	private Sprite[][] clyde;
	private final static int ANIMATION_DURATION = 25;
    private Animation animations[];
    private SuperPacmanPlayer player;
    /*
     * Default Blinky constructor
	 * @param area (Area) : Owner area. Not null 
	 * @param orientation(Orientation) : Blinky orientation. Not null
	 * @param position (DiscreteCoordinates): The blinky position. Not null
	*/
	public Clyde(Area area, Orientation orientation, DiscreteCoordinates coordinates,SuperPacmanPlayer player) {
		super(area, orientation, coordinates);
		//desiredOrientation = orientation;
		this.player= player;
		clyde = RPGSprite.extractSprites("superpacman/ghost.clyde", 2, 1, 1, this, 16, 16, new Orientation[] {Orientation.UP, Orientation.RIGHT, Orientation.DOWN, Orientation.LEFT});
		animations = Animation.createAnimations(ANIMATION_DURATION / 4, clyde);
		setCurrentSpeed(4);
	}
	
	@Override
	public void draw(Canvas canvas) {
		super.draw(canvas);
		animations[getOrientation().ordinal()].draw(canvas);
	}
	
	@Override
	protected void calculWays() {	
		super.calculWays();
	}

	/*
	 * Method that determines a random number that will be the index of a table with 
	 * the different orientations of the ghost
	 */
	@Override
	protected void getNextOrientation() {
		super.getNextOrientation();
	}
	
	@Override
	protected DiscreteCoordinates targetCellRandom(DiscreteCoordinates target, Queue<Orientation> path) {
		
		DiscreteCoordinates position;
		position = player.getPlayerPos();
		return position;
	}
	
	
	@Override
	public void update(float deltaTime) {
		super.update(deltaTime);
		if((isDisplacementOccurs())) {
			animations[getOrientation().ordinal()].update(deltaTime);
		}
	}

	}

