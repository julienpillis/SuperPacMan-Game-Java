package ch.epfl.cs107.play.game.superpacman.area;

import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.rpg.actor.Door;
import ch.epfl.cs107.play.game.superpacman.actor.Bomb;
import ch.epfl.cs107.play.game.superpacman.actor.Gate;
import ch.epfl.cs107.play.game.superpacman.actor.Heart;
import ch.epfl.cs107.play.game.superpacman.actor.Key;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.signal.logic.Logic;


public class Level0 extends SuperPacmanArea {
	
	public final static DiscreteCoordinates PLAYER_SPAWN_POSITION = new DiscreteCoordinates(10,1);
	private final static int NORMAL_SPEED = 6;
	private int SPEED = 6;
	

	private Key key = new Key(this, Orientation.UP, new DiscreteCoordinates(3,4));
	
	
	public String getTitle() {
		return "superpacman/Level0";
	}
	
	
	protected void createArea() {
		 
		 registerActor(new Heart(this, Orientation.UP, new DiscreteCoordinates(8,7)));
		 registerActor(new Door("superpacman/Level1",new DiscreteCoordinates(15,6),Logic.TRUE,this,Orientation.UP,new DiscreteCoordinates(5,9),new DiscreteCoordinates(6,9)));
		 registerActor(key);
		 registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(5,8),key));
		 registerActor(new Gate(this,Orientation.LEFT,new DiscreteCoordinates(6,8),key));
	}
	
	
	@Override
	public DiscreteCoordinates getPlayerSpawnPosition() {
		return PLAYER_SPAWN_POSITION;
	}
	
	@Override
	public void setSpeed(int speed) {
		SPEED=speed;
	}
	
	@Override
	public int getNormalSpeed() {
		return NORMAL_SPEED;
	}
	
	@Override
	public int getSpeed() {
		return SPEED;
	}
	
}
