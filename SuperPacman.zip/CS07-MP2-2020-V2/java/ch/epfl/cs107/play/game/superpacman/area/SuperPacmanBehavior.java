package ch.epfl.cs107.play.game.superpacman.area;

import java.util.ArrayList;
import java.util.List;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.AreaBehavior;
import ch.epfl.cs107.play.game.areagame.AreaGraph;
import ch.epfl.cs107.play.game.areagame.actor.Interactable;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.superpacman.actor.Blinky;
import ch.epfl.cs107.play.game.superpacman.actor.Bonus;
import ch.epfl.cs107.play.game.superpacman.actor.Cherry;
import ch.epfl.cs107.play.game.superpacman.actor.Clyde;
import ch.epfl.cs107.play.game.superpacman.actor.Diamond;
import ch.epfl.cs107.play.game.superpacman.actor.Ghost;
import ch.epfl.cs107.play.game.superpacman.actor.Inky;
import ch.epfl.cs107.play.game.superpacman.actor.Pinky;
import ch.epfl.cs107.play.game.superpacman.actor.Wall;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Window;


public class SuperPacmanBehavior extends AreaBehavior {
	
	private int numberOfDiamonds = 0;			
	private AreaGraph graph;

	public enum SuperPacmanCellType {
		//https://stackoverflow.com/questions/25761438/understanding-bufferedimage-getrgb-output-values
		NONE(0), // never used as real content
		WALL ( -16777216), //black
		FREE_WITH_DIAMOND(-1), //white
		FREE_WITH_BLINKY (-65536), //red
		FREE_WITH_PINKY (-157237), //pink
		FREE_WITH_INKY ( -16724737), //cyan
		FREE_WITH_CHERRY (-36752), //light red
		FREE_WITH_BONUS ( -16478723), //light blue
		FREE_EMPTY ( -6118750); // sort of gray

		final int type;

		SuperPacmanCellType(int type){
			this.type = type;
		}

	public static SuperPacmanCellType toType(int type){
			for(SuperPacmanCellType ict : SuperPacmanCellType.values()){
				if(ict.type == type)
					return ict;
			}
			return NONE;
		}
	}
	
	/**
	 * Default Tuto2Behavior Constructor
	 * @param window (Window), not null
	 * @param name (String): Name of the Behavior, not null
	 */
	public SuperPacmanBehavior(Window window, String name){
		
		super(window, name);
		int height = getHeight();
		int width = getWidth();
		graph = new AreaGraph();
		
		for(int y = 0; y < height; y++) {
            for (int x = 0; x < width ; x++) {
                SuperPacmanCellType color = SuperPacmanCellType.toType(getRGB(height-1-y, x));
                setCell(x,y, new SuperPacmanCell(x,y,color));
            }
        }

        for(int y = 0; y < height; y++) {
            for (int x = 0; x < width ; x++) {
            	
            	boolean hasLeftEdge=false;
            	boolean hasRightEdge=false;
            	boolean hasUpEdge=false;
            	boolean hasDownEdge=false;
            	
                if ((x > 0) && ((SuperPacmanCell)getCell(x-1,y)).type!= SuperPacmanCellType.WALL){
                    hasLeftEdge=true;
                }

                if((x+1 < width) && ((SuperPacmanCell)getCell(x+1,y)).type!= SuperPacmanCellType.WALL) {
                    hasRightEdge=true;
                }

                if((y+1 < height) && ((SuperPacmanCell)getCell(x,y+1)).type!= SuperPacmanCellType.WALL) {
                    hasUpEdge=true;
                }

                if((y > 0) && ((SuperPacmanCell)getCell(x,y-1)).type!= SuperPacmanCellType.WALL) {
                    hasDownEdge=true;
                }

                graph.addNode(new DiscreteCoordinates(x,y), hasLeftEdge, hasUpEdge, hasRightEdge, hasDownEdge);
            }
        }
	}
	
	
	/*
	 * Method that records actors in the playing area
	 * @param area (Area) : Current area. Not null
	 */
	protected void registerActors(Area area) {
		
		((SuperPacmanArea)area).allGhosts= new ArrayList<Ghost>();
		int height = area.getHeight();
		int width = area.getWidth();

		for(int y = 0; y < height; y++) {
			for (int x = 0; x < width ; x++) {
				if (((SuperPacmanCell)getCell(x,y)).type == SuperPacmanCellType.WALL) { 
                    Wall wall = new Wall(area,new DiscreteCoordinates(x,y), neighbouringCellsCheck(x,y,width,height));
                    area.registerActor(wall);
    
				}
				
				if (((SuperPacmanCell)getCell(x,y)).type == SuperPacmanCellType.FREE_WITH_DIAMOND) { 
					Diamond diamond = new Diamond(area,Orientation.UP,new DiscreteCoordinates(x,y));
                    area.registerActor(diamond);
                    numberOfDiamonds+=1;
				}
				
				if (((SuperPacmanCell)getCell(x,y)).type == SuperPacmanCellType.FREE_WITH_CHERRY) { 
					Cherry cherry = new Cherry(area,Orientation.UP,new DiscreteCoordinates(x,y));
                    area.registerActor(cherry);
				}
				
				if (((SuperPacmanCell)getCell(x,y)).type == SuperPacmanCellType.FREE_WITH_BONUS) { 
					Bonus bonus = new Bonus(area,Orientation.UP,new DiscreteCoordinates(x,y));
                    area.registerActor(bonus);
                    
				}
				
				if (((SuperPacmanCell)getCell(x,y)).type == SuperPacmanCellType.FREE_WITH_BLINKY) { 
					Blinky blinky = new Blinky(area,Orientation.UP,new DiscreteCoordinates(x,y));
                    area.registerActor(blinky);
                    ((SuperPacmanArea)area).allGhosts.add(blinky);
				}
				
				if (((SuperPacmanCell)getCell(x,y)).type == SuperPacmanCellType.FREE_WITH_PINKY) { 
					Pinky pinky = new Pinky(area,Orientation.DOWN,new DiscreteCoordinates(x,y));
                    area.registerActor(pinky);
                    ((SuperPacmanArea)area).allGhosts.add(pinky);
				}
				
				if (((SuperPacmanCell)getCell(x,y)).type == SuperPacmanCellType.FREE_WITH_INKY) { 
					Inky inky = new Inky(area,Orientation.DOWN,new DiscreteCoordinates(x,y));
                    area.registerActor(inky);
                    ((SuperPacmanArea)area).allGhosts.add(inky);
				}
			}
		}	
    }
	/*
	 * Method for determining whether neighboring cells in a 3x3 array are walls or not
	 * @param x (int), abscissa of the main cell
	 * @param y (int), ordinate  of the main cell
	 * @param width (int), width of the area
	 * @param height (int), height of the area
	 */	
	public boolean [][] neighbouringCellsCheck(int x, int y, int width, int height){
		
		boolean[][] neighborhood = new boolean[3][3];
		
		if(x==0 && y!=0 && y!=height-1) { // LEFT SIDE
			for(int i = 0; i<=1; i++) {
				 for(int j = -1; j<=1;j++) {
					 if (((SuperPacmanCell)getCell(x+i,y-j)).type == SuperPacmanCellType.WALL) {
						 neighborhood[i+1][j+1]=true;
					 }
					 else {neighborhood[i+1][j+1]=false;}
				 }
			}
			neighborhood[0][0]=false;
			neighborhood[0][1]=false;
			neighborhood[0][2]=false;
		}
		
		else if (y==0 && x!=0 && x!=width-1) {//DOWN SIDE
			for(int i = -1; i<=1; i++) {
				 for(int j = -1; j<=0;j++) {
					 if (((SuperPacmanCell)getCell(x+i,y-j)).type == SuperPacmanCellType.WALL) {
						 neighborhood[i+1][j+1]=true;
					 }
					 else {neighborhood[i+1][j+1]=false;}
				 }
			}
			neighborhood[0][2]=false;
			neighborhood[1][2]=false;
			neighborhood[2][2]=false;
		}
		
		else if (x==width-1 && y!=0 && y!=height-1) { // RIGHT SIDE
			for(int i = -1; i<=0; i++) {
				 for(int j = -1; j<=1;j++) {
					 if (((SuperPacmanCell)getCell(x+i,y-j)).type == SuperPacmanCellType.WALL) {
						 neighborhood[i+1][j+1]=true;
					 }
					 else {neighborhood[i+1][j+1]=false;}
				 }
			}
			neighborhood[2][0]=false;
			neighborhood[2][1]=false;
			neighborhood[2][2]=false;
		}
		
		else if (y==height-1 && x!=0 && x!=width-1) { // UP SIDE
			for(int i = -1; i<=1; i++) {
				 for(int j = 0; j<=1;j++) {
					 if (((SuperPacmanCell)getCell(x+i,y-j)).type == SuperPacmanCellType.WALL) {
						 neighborhood[i+1][j+1]=true;
					 }
					 else {neighborhood[i+1][j+1]=false;}
				 }
			}
			neighborhood[0][0]=false;
			neighborhood[1][0]=false;
			neighborhood[2][0]=false;
		}
		
		else if(x==0 && y==0) {  // DOWN-LEFT CORNER
			 for(int i = 0; i<=1; i++) {
				 for(int j = -1; j<=0;j++) {
					 if (((SuperPacmanCell)getCell(x+i,y-j)).type == SuperPacmanCellType.WALL) {
						 neighborhood[i+1][j+1]=true;
					 }
					 else {neighborhood[i+1][j+1]=false;}
				 }
			}
			neighborhood[0][0]=false;
			neighborhood[0][1]=false;
			neighborhood[0][2]=false;
			neighborhood[1][2]=false;
			neighborhood[2][2]=false;
		}
		
		else if(x==0 && y==height-1) {    //UP-LEFT CORNER
			for(int i = 0; i<=1; i++) {
				 for(int j = 0; j<=1;j++) {
					 if (((SuperPacmanCell)getCell(x+i,y-j)).type == SuperPacmanCellType.WALL) {
						 neighborhood[i+1][j+1]=true;
					 }
					 else {neighborhood[i+1][j+1]=false;}
				 }
			}
			neighborhood[0][0]=false;
			neighborhood[0][1]=false;
			neighborhood[0][2]=false;
			neighborhood[1][0]=false;
			neighborhood[2][0]=false;
		}
		
		else if(x==width-1 && y==0) { // DOWN-RIGHT CORNER
			for(int i = -1; i<=0; i++) {
				 for(int j = -1; j<=0;j++) {
					 if (((SuperPacmanCell)getCell(x+i,y-j)).type == SuperPacmanCellType.WALL) {
						 neighborhood[i+1][j+1]=true;
					 }
					 else {neighborhood[i+1][j+1]=false;}
				 }
			}
			neighborhood[0][2]=false;
			neighborhood[1][2]=false;
			neighborhood[2][2]=false;
			neighborhood[2][1]=false;
			neighborhood[2][0]=false;
		}
		
		else if(y==height-1 && x==width-1) { //UP-RIGHT CORNER
			for(int i = -1; i<=0; i++) {
				 for(int j = 0; j<=1;j++) {
					 if (((SuperPacmanCell)getCell(x+i,y-j)).type == SuperPacmanCellType.WALL) {
						 neighborhood[i+1][j+1]=true;
					 }
					 else {neighborhood[i+1][j+1]=false;}
				 }
			}
			neighborhood[0][0]=false;
			neighborhood[2][2]=false;
			neighborhood[2][1]=false;
			neighborhood[1][0]=false;
			neighborhood[2][0]=false;
		}
		
		else {
            for(int i = -1; i<=1; i++) {
                 for(int j = -1; j<=1; j++) {
                     if (((SuperPacmanCell)getCell(x+i,y-j)).type == SuperPacmanCellType.WALL) {
                         neighborhood[i+1][j+1]=true;
                     }
                     else {neighborhood[i+1][j+1]=false;}
                     }
                }
           }
		return neighborhood;
	}
		
	
	/**
	 * Cell adapted to the SuperPacman game
	 */
	public class SuperPacmanCell extends AreaBehavior.Cell {
		/// Type of the cell following the enum
		private final SuperPacmanCellType type;
		
		/**
		 * Default Tuto2Cell Constructor
		 * @param x (int): x coordinate of the cell
		 * @param y (int): y coordinate of the cell
		 * @param type (EnigmeCellType), not null
		 */
		public  SuperPacmanCell(int x, int y, SuperPacmanCellType type){
			super(x, y);
			this.type = type;
		}
	
		@Override
		protected boolean canLeave(Interactable entity) {
			return true;
		}

		@Override
		protected boolean canEnter(Interactable entity) {
			return (!hasNonTraversableContent()); 
	    }

	    
		@Override
		public boolean isCellInteractable() {
			return true;
		}

		@Override
		public boolean isViewInteractable() {
			return false;
		}

		@Override
		public void acceptInteraction(AreaInteractionVisitor v) {
		}
	}
	
	/*
	 * Getter of the total amout of diamonds present at the construction of the area
	 */
	public int getNumberOfDiamonds() {
		return numberOfDiamonds;
	}
	/*
	 * Getter of the AreaGraph of the area
	 */
	public AreaGraph getGraph() {
		return graph;
	}
}