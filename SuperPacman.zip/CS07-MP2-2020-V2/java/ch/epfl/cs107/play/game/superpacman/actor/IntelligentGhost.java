package ch.epfl.cs107.play.game.superpacman.actor;

import java.util.LinkedList;
import java.util.Queue;
import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Animation;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Path;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Canvas;

public abstract class IntelligentGhost extends Ghost {
	
    private Queue<Orientation> path;
    

	public IntelligentGhost(Area area, Orientation orientation, DiscreteCoordinates coordinates) {
		super(area, orientation, coordinates);
	}
	
	
	@Override
	public void draw(Canvas canvas) {
		super.draw(canvas);
	}
	
	
	@Override
	public void update(float deltaTime) {
		super.update(deltaTime);
	}
	
	/*
	 * Method to calcul the shortest path to the target or a random path if no target in memory
	 */
	protected void calculWays() {	

		if (getMemory()== null) {
			setTargetPos(targetCellRandom(getRefuge(), path));
		}
		
		else {
			setTargetPos(getMemory().getPlayerPos());
		}
		
		path = getGraph().shortestPath(getCurrentMainCellCoordinates(),getTargetPos());

	}
	
	
	protected abstract DiscreteCoordinates targetCellRandom(DiscreteCoordinates refuge, Queue<Orientation> path);


	@Override
	public void isAte() {
		super.isAte();
		path = null;
	}
	
	/*
	 * Method to determine the next Orientation that the ghost will have
	 */
	protected void getNextOrientation() {
		
		if(getMemory()!=null) {
			targetCellRandom(getMemory().getPlayerPos(), path);	
		}
		
		if (getIsGhostAfraid() || getCurrentMainCellCoordinates() == targetCellRandom(getRefuge(), path) || !isDisplacementOccurs() ) {
			if(getStateTransition()) {
				path=null;
				setStateTransition(false);
			}
			calculWays();
		}
		
		if (path == null) {
			setDesiredOrientation(null);
		}
		
		else {
			setDesiredOrientation(path.poll());
		}
		
	}
}
