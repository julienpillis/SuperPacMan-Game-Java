package ch.epfl.cs107.play.game.superpacman;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.rpg.RPG;
import ch.epfl.cs107.play.game.superpacman.actor.EndGUI;
import ch.epfl.cs107.play.game.superpacman.actor.PauseGUI;
import ch.epfl.cs107.play.game.superpacman.actor.SuperPacmanPlayer;
import ch.epfl.cs107.play.game.superpacman.area.Level0;
import ch.epfl.cs107.play.game.superpacman.area.Level1;
import ch.epfl.cs107.play.game.superpacman.area.Level2;
import ch.epfl.cs107.play.game.superpacman.area.Level3;
import ch.epfl.cs107.play.game.superpacman.area.SuperPacmanArea;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.window.Keyboard;
import ch.epfl.cs107.play.window.Window;

public class SuperPacman extends RPG {
	
	public final static float CAMERA_SCALE_FACTOR = 25.f;
	public final static float STEP = 0.05f;
	private final String[] areas = {"superpacman/Level0", "superpacman/Level1","superpacman/Level2", "superpacman/Level3"};
	private int areaIndex;
	private SuperPacmanPlayer player;
	private Keyboard keyboard;
	private boolean pause=false;
	private boolean end=false;
	private PauseGUI pauseMenu ;
	private EndGUI endMenu ;
	private boolean win=false;;
	
	/**
	 * Add all the areas
	 */
	private void createAreas(){

		addArea(new Level0());
		addArea(new Level1());
		addArea(new Level2());
		addArea(new Level3());
	}

	@Override
	public boolean begin(Window window, FileSystem fileSystem) {

		if (super.begin(window, fileSystem)) {
			createAreas();
			areaIndex = 0;
			Area area = setCurrentArea(areas[areaIndex], true);
			player = new SuperPacmanPlayer(area, Level0.PLAYER_SPAWN_POSITION);
			initPlayer(player);
			keyboard = area.getKeyboard();
			return true;
		}
		return false;
	}
	

	@Override
	public void update(float deltaTime) {
		 if(pause) {
			 pauseMenu= new PauseGUI(player.getScore(),player.getLife());
			 pauseMenu.draw(getWindow());
			  if( keyboard.get(Keyboard.SPACE).isPressed() && pause==true) {
					pause=false;
				}
		 }
		 else if(end) {
			endMenu= new EndGUI(player.getScore(),win);
			endMenu.draw(getWindow());
			if(keyboard.get(Keyboard.Q).isPressed()) {
				end();
			}
		}
		else {
			super.update(deltaTime);
			if(player.getStateTransition()) {
				((SuperPacmanArea)getCurrentArea()).setCurrentVulTimer(player.getCurrentBonusTimer());
				((SuperPacmanArea)getCurrentArea()).scareGhosts();
				player.setStateTransition(false);
			}
			endCheck();
			pauseCheck();
		}
	}
	/*
	 * Method that close the windows when game is finished
	 */	
	@Override
	public void end() {
		getWindow().dispose();
	}

	
	@Override
	public String getTitle() {
		return "Super Pac-Man";
	}
	
	
	/*
	 * Method to check if a pause is called by the player
	 */
	private void pauseCheck() {
		if( keyboard.get(Keyboard.SPACE).isPressed() && pause==false) {
			pause=true;
		}
		if(pause) {
			pauseMenu= new PauseGUI(player.getScore(),player.getLife());
			pauseMenu.draw(getWindow());
		}
		
	}
	/*
	 * Method that checks if the game is finished
	 */
	private void endCheck() {
		win=player.getWin();
		if(player.getLife()==0) {
			end=true;
			win=false;
		}
		else if(win){
			end=true;
		}
	}
}

