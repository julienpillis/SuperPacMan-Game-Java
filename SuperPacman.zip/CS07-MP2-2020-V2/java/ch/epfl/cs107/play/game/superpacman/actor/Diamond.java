package ch.epfl.cs107.play.game.superpacman.actor;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.superpacman.handler.SuperPacmanInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Canvas;


public class Diamond extends CollectableAreaEntity {
	
	private Sprite diamond;
	private final static int DIAMOND_POINTS = 10; 
	
	/*
     * Default Diamond constructor
	 * @param area (Area) : Owner area. Not null 
	 * @param orientation(Orientation) : Diamond orientation. Not null
	 * @param position (DiscreteCoordinates): The diamond position. Not null
	*/
	public Diamond(Area area, Orientation orientation, DiscreteCoordinates position) {
		super(area,orientation,position);
		diamond = new Sprite("superpacman/diamond", 1, 1,this);
	}  
	/*
	 * Getter of the bonus points that the player will have when he/she eat a diamond
	 */
	public int score() {
		return DIAMOND_POINTS;
	}
	
	@Override
	public void draw(Canvas canvas) {
		diamond.draw(canvas);
	}
	
	@Override
    public void acceptInteraction(AreaInteractionVisitor v) {
		((SuperPacmanInteractionVisitor)v).interactWith(this);
        getOwnerArea().unregisterActor(this);
    }
}

