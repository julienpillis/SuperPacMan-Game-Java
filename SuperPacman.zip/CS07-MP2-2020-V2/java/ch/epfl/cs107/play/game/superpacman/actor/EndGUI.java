package ch.epfl.cs107.play.game.superpacman.actor;

import java.awt.Color;
import ch.epfl.cs107.play.game.actor.Graphics;
import ch.epfl.cs107.play.game.actor.ImageGraphics;
import ch.epfl.cs107.play.game.actor.TextGraphics;
import ch.epfl.cs107.play.game.areagame.io.ResourcePath;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.window.Canvas;

public class EndGUI implements Graphics{
	
	private int scorePlayer;
	private boolean win;
	private ResourcePath imPath;
	/*
     * Default SuperPacmanPlayerGUI constructor
	 * @param scorePlayer (int) : Score. Not negative
	 * @param win (boolean) : Indicates if the player won or not.
	 * @param actualLives (int) : Actual lives of the SuperPacmanPlayer. Not negative
	*/
	public EndGUI(int scorePlayer,boolean win) {
		this.scorePlayer = scorePlayer;
		this.win=win;
	}
	
	
	@Override
	public void draw(Canvas canvas) {
		TextGraphics menu;
		ImageGraphics image;
		float width = canvas.getScaledWidth();
		float height = canvas.getScaledHeight();
		Vector anchor = canvas.getTransform().getOrigin().sub(new Vector(width/2, height/2));
		if(win) {
			 menu = new TextGraphics("Well done ! You Won", 1.25f, Color.BLACK, Color.YELLOW, 0.1f, false, false, anchor.add(new Vector(1, height - 7f))) ;
		}
		else {
			 menu = new TextGraphics("Game Over...", 1.25f, Color.BLACK, Color.RED, 0.1f, false, false, anchor.add(new Vector(1, height - 7f))) ;

		}
		TextGraphics score = new TextGraphics("Your final score is : "+scorePlayer, 1.25f, Color.BLACK, Color.GREEN, 0.1f, false, false, anchor.add(new Vector(1, height - 9f))) ;
		TextGraphics escape = new TextGraphics("Press 'Q' to quit the game.", 1.25f, Color.BLACK, Color.BLUE, 0.1f, false, false, anchor.add(new Vector(1, height - 11f))) ;
		menu.draw(canvas);
		score.draw(canvas);
		escape.draw(canvas);
	}
}
