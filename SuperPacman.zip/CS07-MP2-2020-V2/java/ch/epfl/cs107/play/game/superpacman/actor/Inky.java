package ch.epfl.cs107.play.game.superpacman.actor;


import java.util.Queue;
import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Animation;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Path;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.rpg.actor.RPGSprite;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Canvas;

public class Inky extends IntelligentGhost {
	
	private Sprite[][] inky;
	private final static int ANIMATION_DURATION = 25;
    private Animation animations[];
    private final static int MAX_DISTANCE_WHEN_SCARED=5;
    private final static int MAX_DISTANCE_WHEN_NOT_SCARED=10;
    private Path graphicPath;
    /*
     * Default Inky constructor
	 * @param area (Area) : Owner area. Not null 
	 * @param orientation(Orientation) : Inky orientation. Not null
	 * @param position (DiscreteCoordinates): The inky position. Not null
	*/
	public Inky(Area area, Orientation orientation, DiscreteCoordinates coordinates) {
		super(area, orientation, coordinates);
		inky = RPGSprite.extractSprites("superpacman/ghost.inky", 2, 1, 1, this, 16, 16, new Orientation[] {Orientation.UP, Orientation.RIGHT, Orientation.DOWN, Orientation.LEFT});
		animations = Animation.createAnimations(ANIMATION_DURATION / 4, inky);
	}
	
	
	@Override
	public void draw(Canvas canvas) {
		super.draw(canvas);
		if(!getIsGhostAfraid()) {
			animations[getOrientation().ordinal()].draw(canvas);
		}
		if(graphicPath!=null) {
			graphicPath.draw(canvas);
		}
	}
	
	
	protected void calculWays() {	
		super.calculWays();
	}

	
	/*
	 * Method that determines a random number that will be the index of a table with 
	 * the different orientations of the ghost
	 */
	@Override
	protected void getNextOrientation() {
		super.getNextOrientation();
	}
	
	
	@Override
	public void isAte() {
		super.isAte();
	}

	
	@Override
	protected DiscreteCoordinates targetCellRandom(DiscreteCoordinates refuge, Queue<Orientation> path) {
		
		float distance;
		DiscreteCoordinates position;
		if (path == null) {
			if (getIsGhostAfraid()) {
			 do {
				 position = randomCoordinatesGenerator();
				 distance = DiscreteCoordinates.distanceBetween(position, refuge);
			 	} while(distance > MAX_DISTANCE_WHEN_SCARED) ;
			 return position;
			}
			
			else {
				do {
					position = randomCoordinatesGenerator();
					distance = DiscreteCoordinates.distanceBetween(position, refuge);
				 } while(distance > MAX_DISTANCE_WHEN_NOT_SCARED) ;
			return position;
			}
		}	
		else {
			return getTargetPos();
		}
	}
	
	
	@Override
	public void update(float deltaTime) {
		super.update(deltaTime);
		
		if(getIsGhostAfraid()) {
			setCurrentSpeed(10);
		}
		else {
			setCurrentSpeed(getNormalSpeed());
		}
		
		if((!getIsGhostAfraid())&&(isDisplacementOccurs())) {
			animations[getOrientation().ordinal()].update(deltaTime);
		}
	}
}


