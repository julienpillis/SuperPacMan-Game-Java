package ch.epfl.cs107.play.game.superpacman.handler;

import ch.epfl.cs107.play.game.rpg.handler.RPGInteractionVisitor;
import ch.epfl.cs107.play.game.superpacman.actor.Bomb;
import ch.epfl.cs107.play.game.superpacman.actor.Ghost;
import ch.epfl.cs107.play.game.superpacman.actor.SuperPacmanPlayer;

public interface GhostInteractionVisitor extends RPGInteractionVisitor {
	default void interactWith(Ghost ghost) {
        // by default the interaction is empty
	}
	
	default void interactWith(SuperPacmanPlayer superPacmanPlayer){
        // by default the interaction is empty
    }
	default void interactWith(Bomb bomb){
        // by default the interaction is empty
    }
	
}