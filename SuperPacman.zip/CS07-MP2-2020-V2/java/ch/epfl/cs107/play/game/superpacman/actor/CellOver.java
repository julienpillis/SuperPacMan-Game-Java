package ch.epfl.cs107.play.game.superpacman.actor;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.superpacman.handler.SuperPacmanInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Canvas;

public class CellOver extends CollectableAreaEntity {
	
    private Sprite cellOver;
    
    /*
     * Default Cherry constructor
	 * @param area (Area) : Owner area. Not null 
	 * @param orientation(Orientation) : cherry orientation. Not null
	 * @param position (DiscreteCoordinates): The cherry position. Not null
	*/
    public CellOver(Area area, Orientation orientation, DiscreteCoordinates position) {
        super(area,orientation,position);
        cellOver = new Sprite("superpacman/CellOver", 1, 1,this);
    }
    @Override
    public void draw(Canvas canvas) {
        cellOver.draw(canvas);
    }
    
    @Override
    public void acceptInteraction(AreaInteractionVisitor v) {
    	((SuperPacmanInteractionVisitor)v).interactWith(this);
        getOwnerArea().unregisterActor(this);
    }
}