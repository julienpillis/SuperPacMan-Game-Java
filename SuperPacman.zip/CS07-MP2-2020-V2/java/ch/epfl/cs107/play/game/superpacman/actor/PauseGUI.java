package ch.epfl.cs107.play.game.superpacman.actor;

import java.awt.Color;

import ch.epfl.cs107.play.game.actor.Graphics;
import ch.epfl.cs107.play.game.actor.ImageGraphics;
import ch.epfl.cs107.play.game.actor.TextGraphics;
import ch.epfl.cs107.play.game.areagame.io.ResourcePath;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.window.Canvas;

public class PauseGUI implements Graphics{
	
	private int scorePlayer;
	private int actualLives;
	private ResourcePath imPath;
	
	
	/*
     * Default SuperPacmanPlayerGUI constructor
	 * @param scorePlayer (int) : Score. Not negative
	 * @param maxLives (int) : Maximum lives of the SuperPacman. Not negative
	 * @param actualLives (int) : Actual lives of the SuperPacmanPlayer. Not negative
	*/
	public PauseGUI(int scorePlayer, int actualLives) {
		this.scorePlayer = scorePlayer;
		this.actualLives=actualLives;
	}
	
	
	@Override
	public void draw(Canvas canvas) {
		float width = canvas.getScaledWidth();
		float height = canvas.getScaledHeight();
		Vector anchor = canvas.getTransform().getOrigin().sub(new Vector(width/2, height/2));
		ImageGraphics image = new ImageGraphics(imPath.getBackgrounds("/superpacman/pacman"), 20f, 10f,null, anchor.add(new Vector(1, height - 14f)));
		TextGraphics menu = new TextGraphics("Vous êtes actuellement en pause.", 1.25f, Color.YELLOW, Color.GREEN, 0.1f, false, false, anchor.add(new Vector(1, height - 6f))) ;
		TextGraphics score = new TextGraphics("Votre score est : "+scorePlayer, 1.25f, Color.BLACK, Color.CYAN, 0.1f, false, false, anchor.add(new Vector(1, height - 13f))) ;
		TextGraphics life = new TextGraphics("Il vous reste "+actualLives+" vies", 1.25f, Color.BLACK, Color.RED, 0.1f, false, false, anchor.add(new Vector(1, height - 15f))) ;
		TextGraphics back = new TextGraphics("Tapez la touche 'ESPACE' pour reprendre.", 1.25f, Color.BLACK, Color.YELLOW, 0.1f, false, false, anchor.add(new Vector(1, height - 17f))) ;
		image.draw(canvas);
		menu.draw(canvas);
		score.draw(canvas);
		life.draw(canvas);
		back.draw(canvas);
	}
}

