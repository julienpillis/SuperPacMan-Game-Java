package ch.epfl.cs107.play.game.superpacman.actor;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Animation;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.rpg.actor.RPGSprite;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.RandomGenerator;
import ch.epfl.cs107.play.window.Canvas;

public class Blinky extends Ghost {
	
	private Sprite[][] blinky;
	private final static int ANIMATION_DURATION = 25;
    private Animation animations[];
    private int randomInt;
    private int MAX=4;
    
    /*
     * Default Blinky constructor
	 * @param area (Area) : Owner area. Not null 
	 * @param orientation(Orientation) : Blinky orientation. Not null
	 * @param position (DiscreteCoordinates): The blinky position. Not null
	*/
	public Blinky(Area area, Orientation orientation, DiscreteCoordinates coordinates) {
		super(area, orientation, coordinates);
		//desiredOrientation = orientation;
		blinky = RPGSprite.extractSprites("superpacman/ghost.blinky", 2, 1, 1, this, 16, 16, new Orientation[] {Orientation.UP, Orientation.RIGHT, Orientation.DOWN, Orientation.LEFT});
		animations = Animation.createAnimations(ANIMATION_DURATION / 4, blinky);
	}
	
	@Override
	public void draw(Canvas canvas) {
		super.draw(canvas);
		if(!getIsGhostAfraid()) {
			animations[getOrientation().ordinal()].draw(canvas);
		}
	}
	
	/*
	 * Method that determines a random number that will be the index of a table with 
	 * the different orientations of the ghost
	 */
	@Override
    protected void getNextOrientation() {
        super.getNextOrientation();
        randomInt = RandomGenerator.getInstance().nextInt(MAX);
        setDesiredOrientation(Orientation.fromInt(randomInt));
    }
	
	@Override
	public void update(float deltaTime) {
		super.update(deltaTime);
		if((!getIsGhostAfraid())&&(isDisplacementOccurs())) {
			animations[getOrientation().ordinal()].update(deltaTime);
		}
	}
}