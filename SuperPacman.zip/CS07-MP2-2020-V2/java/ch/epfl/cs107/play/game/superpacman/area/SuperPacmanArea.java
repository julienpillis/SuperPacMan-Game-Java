package ch.epfl.cs107.play.game.superpacman.area;

import java.util.List;
import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.AreaBehavior;
import ch.epfl.cs107.play.game.areagame.AreaGraph;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.RandomGenerator;
import ch.epfl.cs107.play.signal.logic.Logic;
import ch.epfl.cs107.play.window.Window;
import ch.epfl.cs107.play.game.superpacman.SuperPacman;
import ch.epfl.cs107.play.game.superpacman.actor.Blinky;
import ch.epfl.cs107.play.game.superpacman.actor.Ghost;

public abstract class SuperPacmanArea extends Area implements Logic {
	
	public List<Ghost> allGhosts;
	private SuperPacmanBehavior behavior;
	private boolean signal;
	private int nbDiamonds = 0;
	private float vulTimer=0;			//the Current Vulnerability Timer for ghosts
	
	/*
	 * Method that indicates to the ghosts that they must be afraid ! 
	 */
	public void scareGhosts() {
		for(int i =0; i<allGhosts.size();i++) {
			allGhosts.get(i).ghostIsAfraid();
			allGhosts.get(i).setStateTransition(true);
		}
	}
	
	/*
	 * Method that indicates to the ghosts that they must be afraid ! 
	 */
	public void ateGhosts() {
		for(int i =0; i<allGhosts.size();i++) {
			allGhosts.get(i).isAte();
		}
	}
	/*
	 * Method to get the current speed of the level
	 */
	public int getSpeed() {
		return 0;
	}
	/*
	 * Method to set the current speed in the level
	 */
	public void setSpeed(int speed) {
	}
	/*
	 * Method that return the Normal Speed of the level
	 */
	public int getNormalSpeed() {
		return 0;
	}
	@Override
	public String getTitle() {
		return null;
	}

	@Override
	public float getCameraScaleFactor() {
		return SuperPacman.CAMERA_SCALE_FACTOR;
	}
	
    /**
     * Create the area by adding it all actors
     * called by begin method
     * Note it set the Behavior as needed !
     */
    protected void createArea() {  	
    }
    
    
    @Override
    public boolean begin(Window window, FileSystem fileSystem) {
        if (super.begin(window, fileSystem)) {
            // Set the behavior map
        	behavior = new SuperPacmanBehavior(window, getTitle());
            setBehavior(behavior);
            createArea();
            behavior.registerActors(this);
            signal = false;
            return true;
        }
        return false;
    }
    /*
     * Method that counts the number of eaten diamonds, and has to be called when a diamond is ate
     */
    public void removeADiamond() {
    	++nbDiamonds;
    	if(behavior.getNumberOfDiamonds()==nbDiamonds) {
    		signal= true;
    	}
    }
    
    @Override
    public boolean isOff() {
    	return signal;
    }
    
    @Override
    public boolean isOn() {
    	return !signal;
    }
    
    @Override
    public float getIntensity() {
        if (signal == false) {
        	return 1;
        }
        else {
        	return 0;
        }
    }
    /*
     * Method to get the player's Spawn Position ( will be Override)
     */
    public DiscreteCoordinates getPlayerSpawnPosition() {
    	return null;
    }
    /*
     * Method to get de behavior of the specific current area
     */
    public SuperPacmanBehavior getBehavior() {
    	return behavior;
    }
    /*
     * Method to set the vulnerability timer of(Inky,Pinky & Blinky)
     */
    public void setCurrentVulTimer(float timer) {
    	vulTimer = timer;
    }
    /*
     * Method to get the current vulnerability timer of(Inky,Pinky & Blinky)
     */
    public float getCurrentVulTimer() {
    	return vulTimer;
    }
    /*
     * Method to get the AreaGraph of the behavior
     */
    public AreaGraph getGraph() {
    	return behavior.getGraph();
    }
    /*
     * Method to get all the ghost registered in the current area
     */
    public List<Ghost> getAllGhosts() {
    	return allGhosts;
    }
 
}




