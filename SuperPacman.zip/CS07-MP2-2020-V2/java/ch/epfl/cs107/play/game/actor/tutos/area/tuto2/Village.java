/*
	Author:      Claire Lopez
    Date:        17 nov. 2020
 */

package ch.epfl.cs107.play.game.actor.tutos.area.tuto2;

import ch.epfl.cs107.play.game.SimpleGhost;
import ch.epfl.cs107.play.game.actor.tutos.area.Tuto2Area;
import ch.epfl.cs107.play.game.areagame.actor.Background;
import ch.epfl.cs107.play.game.areagame.actor.Foreground;
import ch.epfl.cs107.play.math.Vector;

public class Village extends Tuto2Area {
	
	@Override
	public String getTitle() {
		return "zelda/Village";
	}
	
	protected void createArea() {
        // Base
	
        registerActor(new Background(this)) ;
        registerActor(new Foreground(this)) ;
        registerActor(new SimpleGhost(new Vector(20, 10), "ghost.2"));
        }	
    
}