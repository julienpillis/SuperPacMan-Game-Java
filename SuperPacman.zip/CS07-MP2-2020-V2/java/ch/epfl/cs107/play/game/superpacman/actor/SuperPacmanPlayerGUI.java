package ch.epfl.cs107.play.game.superpacman.actor;

import java.awt.Color;

import ch.epfl.cs107.play.game.actor.Graphics;
import ch.epfl.cs107.play.game.actor.ImageGraphics;
import ch.epfl.cs107.play.game.actor.TextGraphics;
import ch.epfl.cs107.play.game.areagame.io.ResourcePath;
import ch.epfl.cs107.play.math.RegionOfInterest;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.window.Canvas;

class SuperPacmanPlayerGUI implements Graphics {
	
	private int scorePlayer;
	private int maxLives;
	private int actualLives;
	
	/*
     * Default SuperPacmanPlayerGUI constructor
	 * @param scorePlayer (int) : Score. Not negative
	 * @param maxLives (int) : Maximum lives of the SuperPacman. Not negative
	 * @param actualLives (int) : Actual lives of the SuperPacmanPlayer. Not negative
	*/
	public SuperPacmanPlayerGUI(int scorePlayer, int maxLives, int actualLives) {
		this.scorePlayer = scorePlayer;
		this.maxLives= maxLives;
		this.actualLives=actualLives;
		
	}
	
	@Override
	public void draw(Canvas canvas) {
		float width = canvas.getScaledWidth();
		float height = canvas.getScaledHeight();
		Vector anchor = canvas.getTransform().getOrigin().sub(new Vector(width/2, height/2));
		for(int i = 0; i<maxLives;i++) {
			ImageGraphics life;
			if (i<actualLives) {
				 life = new ImageGraphics(ResourcePath.getSprite("superpacman/lifeDisplay"),1.f, 1.f,new RegionOfInterest(0, 0, 64, 64),anchor.add(new Vector(0+i, height - 1.375f)), 1, 1);
			}
			else {
				 life = new ImageGraphics(ResourcePath.getSprite("superpacman/lifeDisplay"),1.f, 1.f,new RegionOfInterest(64, 0, 64, 64),anchor.add(new Vector(0+i, height - 1.375f)), 1, 1);
			}
			life.draw(canvas);
		}
		TextGraphics score = new TextGraphics("SCORE : " +scorePlayer, 1f, Color.BLACK, Color.YELLOW, 0.1f, false, false, anchor.add(new Vector(maxLives+0.3f, height - 1.250f))) ;
		score.draw(canvas);
	}
	
}