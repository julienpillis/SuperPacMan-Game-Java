package ch.epfl.cs107.play.game.superpacman.area;

import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.rpg.actor.Door;
import ch.epfl.cs107.play.game.superpacman.actor.Bomb;
import ch.epfl.cs107.play.game.superpacman.actor.CellOver;
import ch.epfl.cs107.play.game.superpacman.actor.Clyde;
import ch.epfl.cs107.play.game.superpacman.actor.Gate;
import ch.epfl.cs107.play.game.superpacman.actor.Heart;
import ch.epfl.cs107.play.game.superpacman.actor.Key;
import ch.epfl.cs107.play.game.superpacman.actor.Rock;
import ch.epfl.cs107.play.game.superpacman.actor.Shadow;
import ch.epfl.cs107.play.game.superpacman.actor.Teleportation;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.signal.logic.Logic;
import ch.epfl.cs107.play.signal.logic.Or;


public class Level3 extends SuperPacmanArea  {
	
	public final static DiscreteCoordinates PLAYER_SPAWN_POSITION = new DiscreteCoordinates(15,29);
	private  int SPEED = 3;
	private final static int NORMAL_SPEED = 3;
	
	private Key key1 = new Key(this, Orientation.UP, new DiscreteCoordinates(3,16));
	private Key key2 = new Key(this, Orientation.UP, new DiscreteCoordinates(26,16));
	private Key key3 = new Key(this, Orientation.UP, new DiscreteCoordinates(2,8));
	private Key key4 = new Key(this, Orientation.UP, new DiscreteCoordinates(27,8));


	public String getTitle() {
		return "superpacman/Level3";
	}
	
	
	protected void createArea() {
		
		registerActor(new Shadow(this, Orientation.UP, new DiscreteCoordinates(21,12)));
		registerActor(new Shadow(this, Orientation.UP, new DiscreteCoordinates(8,12)));
		//registerActor(new Rock(this, Orientation.UP, new DiscreteCoordinates(24,16)));
		//registerActor(new Rock(this, Orientation.UP, new DiscreteCoordinates(22,16)));
		//registerActor(new Rock(this, Orientation.UP, new DiscreteCoordinates(20,15)));
		//registerActor(new Rock(this, Orientation.UP, new DiscreteCoordinates(25,11)));
		registerActor(new Bomb(this, Orientation.UP, new DiscreteCoordinates(23,27)));
		registerActor(new Bomb(this, Orientation.UP, new DiscreteCoordinates(21,24)));
		registerActor(new Bomb(this, Orientation.UP, new DiscreteCoordinates(25,24)));
		registerActor(new Bomb(this, Orientation.UP, new DiscreteCoordinates(6,27)));
		registerActor(new Bomb(this, Orientation.UP, new DiscreteCoordinates(4,24)));
		registerActor(new Bomb(this, Orientation.UP, new DiscreteCoordinates(8,24)));
		registerActor(new Heart(this, Orientation.UP, new DiscreteCoordinates(6,2)));
		registerActor(new Heart(this, Orientation.UP, new DiscreteCoordinates(23,2)));		
		registerActor(new Teleportation(this, Orientation.UP, new DiscreteCoordinates(1,12), new DiscreteCoordinates(25,28)));
		registerActor(new Teleportation(this, Orientation.UP, new DiscreteCoordinates(28,28), new DiscreteCoordinates(3,12)));
		
		registerActor(key1);
		registerActor(key2);
		registerActor(key3);
		registerActor(key4);
		
		registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(8,14), key1));
		registerActor(new Gate(this,Orientation.DOWN,new DiscreteCoordinates(5,12), key1));
		registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(8,10), key1));
		registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(8,8), key1));
		registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(21,14), key2));
		registerActor(new Gate(this,Orientation.DOWN,new DiscreteCoordinates(24,12), key2));
		registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(21,10), key2));
		registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(21,8), key2));
		registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(10,2), new Or(key3, key4)));
		registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(19,2), new Or(key3,key4)));
		registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(12,8), new Or(key3,key4)));
		registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(17,8), new Or(key3,key4)));
		registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(14,3),this));
		registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(15,3),this));
		registerActor(new CellOver(this,Orientation.RIGHT,new DiscreteCoordinates(15,2)));
		registerActor(new CellOver(this,Orientation.RIGHT,new DiscreteCoordinates(14,2)));

	}
	
	
	@Override
	public DiscreteCoordinates getPlayerSpawnPosition() {
		return PLAYER_SPAWN_POSITION;
	}
	
	
	@Override
	public void setSpeed(int speed) {
		SPEED=speed;
	}
	
	@Override
	public int getNormalSpeed() {
		return NORMAL_SPEED;
	}
	
	@Override
	public int getSpeed() {
		return SPEED;
	}
}

