/*
	Author:      Claire Lopez
    Date:        15 nov. 2020
 */

package ch.epfl.cs107.play.game.actor.tutos.area.tuto1;

import ch.epfl.cs107.play.game.SimpleGhost;
import ch.epfl.cs107.play.game.actor.tutos.area.SimpleArea;
import ch.epfl.cs107.play.game.areagame.actor.Background;
import ch.epfl.cs107.play.math.Vector;


public class Village extends SimpleArea {
	
	@Override
	public String getTitle() {
		return "zelda/Village";
	}
	
	@Override
	protected void createArea() {
        // Base
	
        //registerActor(new Background(this)) ;
		registerActor(new SimpleGhost(new Vector(20, 10), "ghost.2"));
		registerActor(new Background(this));

        }	
    
}