package ch.epfl.cs107.play.game.superpacman.handler;

import ch.epfl.cs107.play.game.rpg.handler.RPGInteractionVisitor;
import ch.epfl.cs107.play.game.superpacman.actor.Bomb;
import ch.epfl.cs107.play.game.superpacman.actor.Bonus;
import ch.epfl.cs107.play.game.superpacman.actor.CellOver;
import ch.epfl.cs107.play.game.superpacman.actor.Cherry;
import ch.epfl.cs107.play.game.superpacman.actor.Clyde;
import ch.epfl.cs107.play.game.superpacman.actor.Diamond;
import ch.epfl.cs107.play.game.superpacman.actor.Ghost;
import ch.epfl.cs107.play.game.superpacman.actor.Heart;
import ch.epfl.cs107.play.game.superpacman.actor.Key;
import ch.epfl.cs107.play.game.superpacman.actor.Shadow;
import ch.epfl.cs107.play.game.superpacman.actor.SuperPacmanPlayer;
import ch.epfl.cs107.play.game.superpacman.actor.Teleportation;

public interface SuperPacmanInteractionVisitor extends RPGInteractionVisitor {
	
	/*
     * Default Inky constructor
	 * @param interactable (Interactable) : Not null
	*/
	default void interactWith(SuperPacmanPlayer superPacmanPlayer){
        // by default the interaction is empty
    }
	
	default void interactWith(Cherry cherry) {
		// by default the interaction is empty
	}
	
	default void interactWith(Diamond diamond) {
		// by default the interaction is empty
	}
	
	default void interactWith(Key key) {
		// by default the interaction is empty
	}
	default void interactWith(Bonus bonus) {
		// by default the interaction is empty
	}
	default void interactWith(Ghost ghost) {
		// by default the interaction is empty
	}
	default void interactWith(Shadow shadow) {
		// by default the interaction is empty
	}
	default void interactWith(Teleportation teleportation) {
		// by default the interaction is empty
	}
	default void interactWith(Heart heart) {
		// by default the interaction is empty
	}
	default void interactWith(Bomb bomb) {
		// by default the interaction is empty
	}
	default void interactWith(CellOver cellOver) {
		// by default the interaction is empty
	}
	default void interactWith(Clyde clyde) {
		// by default the interaction is empty
	}
	
	
}


