package ch.epfl.cs107.play.game.superpacman.actor;

import java.util.ArrayList;
import java.util.List;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Animation;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.rpg.actor.RPGSprite;
import ch.epfl.cs107.play.game.superpacman.area.SuperPacmanArea;
import ch.epfl.cs107.play.game.superpacman.handler.SuperPacmanInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Canvas;

public class Bomb extends CollectableAreaEntity {
	
	private Sprite[] bomb;
	private Sprite[] explosion;
	private final static int ANIMATION_DURATION = 25;
    private final static float EXPLOSION_TIMER = 20;
    private float currentImminentExplosion;
    private Animation animationsExplosion;
    private Animation animationsBomb;
    private boolean imminentExplosion;
    private final static int BOMB_POINTS = 100;

	
    
	public Bomb(Area area, Orientation orientation, DiscreteCoordinates position) {
		super(area, orientation, position);
		imminentExplosion = false;
		bomb = RPGSprite.extractSprites("superpacman/bomb", 2, 1, 1, this, 16, 16);
		explosion = RPGSprite.extractSprites("superpacman/explosion", 7, 1, 1, this, 32, 32);
        animationsExplosion = new Animation(ANIMATION_DURATION / 4, explosion);
        animationsBomb = new Animation(ANIMATION_DURATION / 4, bomb);
		
	}
	
	 @Override
	    public void update(float deltaTime) {
	        super.update(deltaTime);
	        if (imminentExplosion) {
	        	currentImminentExplosion --;
	        }
	        animationsExplosion.update(deltaTime);
	        animationsBomb.update(deltaTime);

	    }
	 @Override
	    public void draw(Canvas canvas) {
	    	if (imminentExplosion) {
	    		animationsExplosion.draw(canvas);
	    		if (currentImminentExplosion == 0) {
	    			getOwnerArea().unregisterActor(this);
	    		}
	    	}
	    	else {
	    		animationsBomb.draw(canvas);
	    	}
	    }
	    
	    /**
	     * If the method collect is called. The signal of the key becomes TRUE. 
	     */
	    @Override
	    public void acceptInteraction(AreaInteractionVisitor v) {
	        ((SuperPacmanInteractionVisitor)v).interactWith(this);
	    }
	    /*
	     * Getter of the duration of the bonus when the bomb is hit by the player
	     */
	    public float getExplosionTimer() {
	        return EXPLOSION_TIMER;
	    }
	    /*
	     * Method that sets the current timer of the explosion and indicates that an explosion will happen
	     */
	    public void explosion() {
	    	imminentExplosion = true;
	    	currentImminentExplosion = getExplosionTimer();
	    	
	    }
	    /*
	     * Return the score that impact the player
	     */
	    public int score() {
            return BOMB_POINTS;
        }
}
